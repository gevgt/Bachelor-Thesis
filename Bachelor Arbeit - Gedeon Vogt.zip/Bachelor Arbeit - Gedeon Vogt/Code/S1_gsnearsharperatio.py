import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import D4_gsnear, D3_dates

dates = D3_dates.dates()
prices = D4_gsnear.gsnear()
x = prices[1:, :] / prices[0:-1, :] - 1		#asset returns
threshold = 0.03							#threshold when rebalancing is triggered
wopt = np.array([0.6, 0.4])					#Strategic asset weights
pfs = 1000									#Portfolio Size in $; required to scale chart
pfv = np.array([pfs])						#Array of Portfolio Values for each point in time in $
av = wopt * pfs								#starting value for each asset in $
sumdev = 0									#Sum of deviation to calculate transaction costs
count = 0

for i in range(x.shape[0]):
	av = av * (1 + x[i,:])					#current asset values
	cpfv = np.sum(av)						#current portfolio value
	pfv = np.append(pfv, cpfv)				#appending current asset value to array
	cw = av / np.sum(av)					#current asset weights
	dev = cw - wopt 						#current deviation from strategic allocation
	pdrift = np.sum(abs(dev))/2				#portfolio drift
	if float(pdrift) >= threshold:
		av = wopt * cpfv
		sumdev += np.sum(abs(dev))
		count += 1

#describing time series
pfr = pfv[1:] / pfv[0:-1] -1				#portfolio returns
pfm = np.mean(pfr) * 250					#mean of portfolio returns
pfstd = np.std(pfr) * np.sqrt(250)			#volatility of portfolio returns
sr = pfm / pfstd							#sharpe ratio

#sharpe ratio after costs
tacosts = sumdev * (0.6 * 0.004 + 0.4 * 0.0002)/(x.shape[0]/250)	#transaction costs
ercost = 0.4 * 0.0025						#expense ratio of NEAR
totc = tacosts + ercost						#total costs
srafterc = (pfm - totc)/pfstd

plt.plot(dates, pfv, linewidth = 1)
#plt.show()
print("-- Goldman Sachs + Bonds (60/40) --")
print("Threshold: " +  str(threshold))
print("Sharpe Ratio: " + str(round(sr,4)))
print("Annualized Mean Return: " + str(round(pfm, 4)))
print("Annualized volatility: " + str(round(pfstd, 4)))
print("Rebalancing Count: " + str(count))
print()
print("AFTER COSTS")
print("Costs: " + str(round(totc,4)))
print("Sharpe Ratio: " + str(round(srafterc,4)))
print("Annualized Mean Return: " + str(round(pfm - totc, 4)))
print()
