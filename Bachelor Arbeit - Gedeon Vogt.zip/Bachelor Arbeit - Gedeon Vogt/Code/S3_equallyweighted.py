import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import D1_data, D3_dates

#STRATEGY: EQUALLY WEIGHTED

#data
dates = D3_dates.dates()
mcstocks, stockreturns, bondreturns, rf = D1_data.daten()

#variables
threshold = 0.03
A = 207													#start
wopt = np.array([0.6/6, 0.6/6, 0.6/6, 0.6/6, 0.6/6, 0.6/6, 0.4/5, 
	0.4/5, 0.4/5, 0.4/5, 0.4/5])						#Strategic asset weights: Nonetheless, Equity: 60% and Fixed Income: 40%
x = np.concatenate([stockreturns[A:,:], bondreturns[A:,:]], axis = 1)
pfs = 1000												#Portfolio Size in $
pfv = np.array([pfs])									#Array of Portfolio Values for each point in time in $
av = wopt * pfs											#starting value for each asset in $
sumdev = 0												#sum of deviation to later calculate transaction costs
count = 0

#rebalancing
for i in range(x.shape[0]):
	av = av * (1 + x[i,:])								#current asset values
	cpfv = np.sum(av)									#current portfolio value
	pfv = np.append(pfv, cpfv)							#appending current asset value to array
	cw = av / np.sum(av)								#current asset weights
	dev = cw - wopt 									#current deviation from strategic allocation
	pdrift = np.sum(abs(dev))/2							#portfolio drift
	if float(pdrift) >= threshold:						#if portfolio drift is higher as threshold allows -> rebalancing
		av = wopt * cpfv
		sumdev += np.sum(abs(cw-wopt))
		count += 1

#characteristics of time series
pfr = pfv[1:] / pfv[0:-1] -1							#portfolio returns
pfm = np.mean(pfr) * 250								#mean of portfolio returns
pfstd = np.std(pfr) * np.sqrt(250)						#volatility of portfolio returns
sr = pfm / pfstd										#sharpe ratio

#sharpe ratio after costs
tacosts = sumdev * 0.00021/(x.shape[0]/250)		#transaction costs: sum of deviations * average bid-ask spread scaled for 1 year
eratio = np.array([0.0003, 0.0004, 0.0007, 0.0007, 0.0005, 0.0012, 0.0006, 0.0015, 0.0025, 0.0009, 0.0039,]) #expense ratios
ercost = np.sum(0.6 * eratio[:6] / 6) + np.sum(0.4 * eratio[6:] / 5) #average ETF cost per year
totc = tacosts + ercost							#total costs
srafterc = (pfm - totc)/pfstd					#sharpe ratio after costs

#plotting line chart
plt.plot(dates, pfv, linewidth = 1)
#plt.show()

#output
print("-- Equally Weighted Portfolio --")
print("Threshold: " +  str(threshold))
print("Sharpe Ratio: " + str(round(sr,4)))
print("Annualized Mean Return: " + str(round(pfm, 4)))
print("Annualized volatility: " + str(round(pfstd, 4)))
print("Rebalancing Count: " + str(count))
print()
print("AFTER COSTS")
print("Costs: " + str(round(totc,4)))
print("Sharpe Ratio: " + str(round(srafterc,4)))
print("Annualized Mean Return: " + str(round(pfm - totc, 4)))
print()