import numpy as np 
import pandas as pd
from matplotlib import pyplot as plt
import S7_betterment, S4_wsetonce, S3_equallyweighted, S2_mscibondsharperatio, S1_gsnearsharperatio

plt.legend(["Betterment", "Weight only set once", "Equally Weighted", "MSCI WORLD + Bonds (60/40)", "Goldman Sachs + Bonds"])
plt.xlabel("07-31-2014 to 04-29-2019")
plt.ylabel("Portfolio Value in $")
plt.savefig("vergleich.pdf")
plt.show()