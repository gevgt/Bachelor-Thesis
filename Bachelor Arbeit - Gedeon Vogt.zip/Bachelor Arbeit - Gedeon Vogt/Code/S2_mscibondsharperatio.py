import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import D5_mscibond, D3_dates

dates = D3_dates.dates()
prices = D5_mscibond.mscibond()
x = prices[1:, :] / prices[0:-1, :] - 1		#asset returns
threshold = 0.03							#threshold when rebalancing is triggered
wopt = np.array([0.6, 0.2, 0.2])			#Strategic asset weights of MSCI World + SHV + NEAR
pfs = 1000									#Portfolio Size in $; required to scale chart
pfv = np.array([pfs])						#Array of Portfolio Values for each point in time in $
av = wopt * pfs								#starting value for each asset in $
sumdev = 0									#sum of deviation to later calculate transaction costs
count = 0

for i in range(x.shape[0]):
	av = av * (1 + x[i,:])					#current asset values
	cpfv = np.sum(av)						#current portfolio value
	pfv = np.append(pfv, cpfv)				#appending current asset value to array
	cw = av / np.sum(av)					#current asset weights
	dev = cw - wopt 						#current deviation from strategic allocation
	pdrift = np.sum(abs(dev))/2				#portfolio drift
	if float(pdrift) >= threshold:
		av = wopt * cpfv
		sumdev += np.sum(abs(cw-wopt))
		count += 1

#characteristics of times series
pfr = pfv[1:] / pfv[0:-1] -1				#portfolio returns
pfm = np.mean(pfr) * 250					#mean of portfolio returns
pfstd = np.std(pfr) * np.sqrt(250)			#volatility of portfolio returns
sr = pfm / pfstd							#sharpe ratio

#sharpe ratio after costs
tacosts = sumdev * (0.6 * 0.0007 + 0.2 * 0.0001 + 0.2 * 0.0002)/(x.shape[0]/250)		#transaction costs
ercosts = 0.6 * 0.0024 + 0.2 * 0.0015 + 0.2 * 0.0025	#expense ratio
totc = tacosts + ercosts								#total costs
srafterc = (pfm - totc)/pfstd							#sharpe ratio after costs

plt.plot(dates, pfv, linewidth = 1)
#plt.savefig("mscibond.pdf")
#plt.show()
print("-- MSCI World + Bonds (60/40) --")
print("Threshold: " +  str(threshold))
print("Sharpe Ratio: " + str(round(sr,4)))
print("Annualized Mean Return: " + str(round(pfm, 4)))
print("Annualized volatility: " + str(round(pfstd, 4)))
print("Rebalancing Count: " + str(count))
print()
print("AFTER COSTS")
print("Costs: " + str(round(totc,4)))
print("Sharpe Ratio: " + str(round(srafterc,4)))
print("Annualized Mean Return: " + str(round(pfm - totc, 4)))
print()