import numpy as np; np.random.seed(0)
import seaborn as sns; sns.set()
from matplotlib import pyplot as plt

sr = np.array([[0.3239,	0.3557,	0.3934,	0.3897,	0.3749,	0.379,	0.3731,	0.375],
[0.6302,	0.6426,	0.635,	0.6302,	0.6521,	0.637,	0.6454,	0.648],
[0.6643,	0.6693,	0.705,	0.6786,	0.682,	0.6815,	0.6763,	0.6777],
[0.7444,	0.7458,	0.7839,	0.7445,	0.7585,	0.7543,	0.752,	0.7542],
[0.7036,	0.7036,	0.7036,	0.7036,	0.7114,	0.7105,	0.7105,	0.7097],
[0.8116,	0.8116,	0.8116,	0.8116,	0.8223,	0.8162,	0.8179,	0.8186],
[0.8226,	0.8226,	0.8226,	0.8226,	0.8333,	0.8272,	0.8293,	0.8298]])

beschriftung = np.array(["Goldman Sachs + NEAR (60/40)",	"MSCI World + SHV + NEAR (60/20/20)",	"Equally weighted",
	 "Weights only set once", "Betterment w/o views", "Betterment w/o shrunken cvm", "Betterment w historic average as view"])

threshold = np.array(["w/o", ".06", ".05", ".04", ".03", ".02", ".01" ,".0"])

ax = sns.heatmap(sr, vmin = 0.3, vmax = 0.85, cmap="YlGnBu", cbar = False)
ax.set_xticklabels(threshold)
ax.set_yticklabels(beschriftung)
ax.set_title("(a) Sharpe Ratio before Costs")
plt.yticks(rotation=0)
plt.savefig("heat_before.pdf", bbox_inches='tight')
plt.show()
