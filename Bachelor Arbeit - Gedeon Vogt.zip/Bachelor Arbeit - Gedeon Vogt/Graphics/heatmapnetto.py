import numpy as np; np.random.seed(0)
import seaborn as sns; sns.set()
from matplotlib import pyplot as plt

sr = np.array([[0.3171,	0.3478,	0.3834,	0.3792,	0.3643,	0.3666,	0.3577,	0.3449],
[0.6035,	0.6149,	0.6074,	0.6029,	0.6242,	0.6092,	0.617,	0.6163],
[0.6509,	0.6555,	0.691,	0.6649,	0.6682,	0.6676,	0.6622,	0.6618],
[0.7308,	0.7318,	0.7696,	0.7305,	0.7443,	0.74,	0.7376,	0.7381],
[0.6584,	0.6584,	0.6584,	0.6584,	0.6662,	0.6654,	0.6653,	0.6629],
[0.7645,	0.7645,	0.7645,	0.7645,	0.7753,	0.7694,	0.7709,	0.7698],
[0.7754,	0.7754,	0.7754,	0.7754,	0.7861,	0.7802,	0.7821,	0.7808]])

beschriftung = np.array(["Goldman Sachs + NEAR (60/40)",	"MSCI World + SHV + NEAR (60/20/20)",	"Equally weighted",
	 "Weights only set once", "Betterment w/o views", "Betterment w/o shrunken cvm", "Betterment w historic average as view"])

threshold = np.array(["w/o", ".06", ".05", ".04", ".03", ".02", ".01" ,".0"])

ax = sns.heatmap(sr, vmin = 0.3, vmax = 0.85, cmap="YlGnBu", yticklabels = False)
ax.set_xticklabels(threshold)
ax.set_yticklabels(beschriftung)
ax.set_title("(b) Sharpe Ratio after Costs")
plt.yticks(rotation=0)
plt.savefig("heat_after.pdf", bbox_inches='tight')
plt.show()
